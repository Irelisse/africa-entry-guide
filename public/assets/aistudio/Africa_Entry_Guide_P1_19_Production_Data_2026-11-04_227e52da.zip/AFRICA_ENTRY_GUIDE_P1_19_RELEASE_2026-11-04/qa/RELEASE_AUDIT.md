# P1 release QA (2026-11-04)

- Selected 19 `CORE_VERIFIED` source records from the canonical Drive ZIP.
- Excluded all 4 `NEEDS_FIELD_QA` records.
- Verified exact section sequence 1–11 for each included country.
- Preserved all canonical source texts and original section descriptions.
- Created per-country JSON and deployable static HTML page, plus searchable index.
- Checked presence of source URLs and absence of private Gmail links.
- Preserved source SHA256 for provenance.
- **Scope restriction:** basic tourist route only; do not infer approval of unresolved special cases.
- **Not tested:** live visa applications, payment checkout, carrier boarding rules and on-site issuance.
- GitHub React/TypeScript integration is a separate process and needs passing its own build checks before merging into main.
