# Africa Entry Guide — P1 / 19 core-verified tourist routes

**Source edition:** 2026-11-04. **Profile:** Russian ordinary biometric passport, tourism.

This package provides 19 complete canonical Markdown files (11 sections each), 19 structured JSON records, a static deployable website and quality-audit data. It deliberately excludes Cameroon, Madagascar, Somalia and Chad.

**Release scope:** Verified basic tourist route only. Secondary or dynamic facts such as special border posts, cumulative visits, fees from live checkout and extensions remain conditional or unknown as stated in each country sheet. It would be misleading to claim every field was fully verified.

The `site/` directory can be deployed as static HTML without a build step. `countries/` contains original canonical source texts; `data/` machine-readable records. The source notes are preserved; unknown fields are not converted to numbers or false.

No private embassy email URLs are included.
